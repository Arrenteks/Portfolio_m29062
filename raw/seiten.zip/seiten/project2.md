# Musikplayer

Dieses Projekt ist ein in Java geschriebenes Soloprojekt zum Abspielen von Sounddateien über ein simples Interface. 

## Inspiration
Jeder liebt Musik. Ich denke niemand wird mir bei dieser Aussage widersprechen. Aber seit ihr nicht auch genervt von der Werbung auf Spotify, YouTube, Deezer usw.? Ich weiß das ich es war.<br/>
Die Lösung? Ich nutze mein Wissen der Java Programmierung und schreibe meinen eigenen Musikplayer. Genau so entstand die Idee hinter dem hier so kreativ benannten "Musikplayer".
Leider besteht im Moment nur die Möglichkeit .wav und .oog Dateien abzuspielen. Da es aber noch ein Work in Progress ist sollte ich es also bald um .mp4 und weitere Dateien sowie ein
bereits in Skizzen vorliegendes User Interface erweitern.

## Das "Team"

**Programming:** Daniel Adam<br/>
**UI Design:** Daniel Adam


## Technische Details

**Programmiersprache:** Java 17<br/>
**Versionsverwaltung:** Github hier zum Projekt: <https://github.com/Arrenteks/Musicplayer><br/>
**Zustand:** Work in Progress