# Dieses Portfolio

Dieses Portfolio entstand im 5. Semester im Zuge des Moduls "Ausgewählte Themen der Webprogrammierung" als 

## Vorgehen

Das Vorgehen bei dieser Abgabe war relativ schnell voraus und soll in diesem Kapitel nur kurz erläutert werden, da in den folgenden Kapiteln genauer auf mögliche Stolperstellen und meinen Lösungsansatz eingegangen werden soll. Zuerst verschaffte ich mir mithilfe der Beispiele auf dem Github „media-informatics“ eine grobe Übersicht über die Möglichkeiten einer Umsetzung einer Website mit Go und etwaigen externen Bibliotheken wie russross, gopls und mongo. Nach einem kurzen Überblick über die Möglichkeiten erschuf ich mir einen Plan wie ich an das Umsetzen der Website gehen sollte. Nach der Erschaffung des Quellverzeichnisbaumes setze ich den Plan sogleich in die Tat um. Der Plan sah vor zuerst die Website aus Templates zu bauen und anschließen immer mehr Features, wie eine MongoDB Datenbankanbindung zu implementieren und dabei das gleiche Ergebnis wie zuvor zu Erschaffen. Also baute ich zuerst eine Website aus verschiedenen Templates zusammen und erhielt ein Ergebnis mit dem ich sehr zufrieden war. Nachdem die Website am Port 9000 zu erreichen war beschäftigte ich mich mit der MongoDB und ihrer Dokumentation. Nachdem ich damit vertraut war baute ich die für mein Projekt notwendigen Collections und Funktionen für den Zugriff auf die Dateien. Danach war es nur noch eine Frage die von dem Einbau der erhaltenen Daten in die bereits bestehenden Templates. Als die Website erneut so aussah wie am Vortag und mir nun mithilfe einer Datenbank die Inhalte remote zukommen lies beschäftigte ich mich mit der Automatisierung mit Docker. Die yaml-Datei und Dockerapp.go Datei für den Docker waren schnell verfasst und auch wenn ich zwischenzeitlich, aufgrund eines Verständnisfehlers, einige Probleme mit der Verbindung zwischen Datenbank und App innerhalb des Dockernetzwerks hatte so lief bald meine Website ohne manuelle Ausführung auf Port 9000 und es war an der Zeit die Dokumentation zu schreiben.

## Technische Details
**Programmiersprache:** Go 1.19<br/>
**Versionsverwaltung:** Github hier zum Projekt: <https://github.com/Arrenteks/Portfolio_m29062.git><br/>
**Zustand:** Entwicklung finalisiert

## Designentscheidungen

### MongoDB Dateien oder Lokale Dateien

Eine Frage die sich mir bereits relativ früh in der Entwicklung stellte war: Sollte ich alle Dateien in der Datenbank halten und in einem komplett leeren Quellverzeichnis alles erstellen lassen oder sollten zumindest ein paar Elementare Dateien lokal im Verzeichnis vorliegen?
Am Ende entschied ich mich für das lokale Vorliegen von elementaren Dateien. So liegen die Bilder, und die CSS-Datei bereits im Quellverzeichnis während die Markdown Dateien und HTML-Templates als Zip Dateien aus der Mongo-DB geladen werden und anschließend entpackt werden. Die Markdown-Dateien und HTML-Templates, welche aktiv darzustellende Daten liefern, liegen in der MongoDB vor und werden in das Quellverzeichnis nach Starten des Containers geladen und dann dem Algorithmus übergeben. Dies liefert unabhängig von der Übung mit MongoDB den Vorteil, dass ich Änderungen direkt in die Datenbank laden kann und sie, nach einem Neustart des Containers, auf der Website angezeigt werden.


### Vorladen der Dateien/Pages

Innerhalb des Codes habe ich mich dazu entschieden die einzufügenden Dateien bereits in einen Slice mit dem Namen pages vorzuladen und diesen lediglich beim Aufrufen der HTML Responses zurück zu geben. Dies hat den Vorteil, dass die Zugriffszeiten sehr schnell erfolgen, da der Slice und damit die HTML Seiten nicht neu erstellt werden müssen. Jedoch liegt der Nachteil in diesem Ansatz darin, dass Änderungen erst nach einem Neustart des Docker Containers mit docker-compose up übernommen werden. Ich musste hier also die Wahl treffen zwischen schneller Zugriffszeit oder sofortigem Sehen der inhaltlichen Änderungen. Da es sich bei den dargestellten Inhalten um statische, sich kaum bis gar nicht ändernde Websites handelt war die schnellere Zugriffszeit mir hier wichtiger als das sofortige Einsehen von Änderungen.

### static. HTML-Templates
Diese Designentscheidung wurde eher aus dem Umstand geboren, dass ich die fertigen, statischen HTML Seiten in einem separaten Ordner mit dem Namen „static“ gespeichert habe. Da diese Seiten in einem separaten Verzeichnis liegen funktionieren einige Verlinkungen aus den normalen Templates nicht und dementsprechend werden Dinge wie Bilder oder die CSS auf den Seiten falsch oder gar nicht angezeigt. Also musste ich hier die Entscheidung fällen eigenständige Template Dateien zu erstellen, welche die richtigen Links enthielten. Diese habe ich mit dem vorangestellten Namen „static.“ Markiert und finden lediglich beim Erstellen der statischen HTML-Seiten Anwendung.

### GridFS
GridFS ist eine Möglichkeit größere Binärdateien, wie Bilder in der MongoDB zu speichern. Ich habe mich nach längerem hin und her dazu entschieden diese Art der Speicherung in mein Programm zu implementieren, da es mir die direkte Speicherung von Zip Dateien in der Datenbank ohne möglichen Datenverlust durch das Konvertieren in BSON ermöglicht. Dafür habe ich mir die Dokumentation zu dem Thema angesehen und es für meine Zwecke umgesetzt. Nicht nur habe ich weitere Erfahrungen im Umgang mit Go gesammelt, sondern verstehe nun auch das Umsetzen einer NoSQL Datenbank als Speicherort für Dateien. Auf diese Art und Weise speichere ich beim Start des Programmes meine Zip Dateien für meine Markdown Dateien und meine HTML-Templates in der MongoDB und kann sie runter laden ohne das sich Konvertierungsprobleme einstellen können, da ich den Inhalt genauso zurück erhalte wie ich ihn hoch geladen habe.